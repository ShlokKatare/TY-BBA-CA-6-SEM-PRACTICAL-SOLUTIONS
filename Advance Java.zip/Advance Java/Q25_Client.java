import java.net.*;
import java.io.*;

class Q25_Client
{
	public static void main(String[] agrs) throws Exception
	{
		Socket s = new Socket("localhost",1234);
		System.out.println("Connected to: "+s.getRemoteSocketAddress());

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		DataInputStream in  = new DataInputStream(s.getInputStream());
		DataOutputStream out  = new DataOutputStream(s.getOutputStream());

		while(true)
		{
			System.out.print("To Server: ");
			String smsg = br.readLine();
			if(!smsg.equals("exit"))
			{
				out.writeUTF(smsg);
			}
			else
			{
				break;
			}
			System.out.println("From Server: "+in.readUTF());
		}

		in.close();
		out.close();
		s.close();
	}
}