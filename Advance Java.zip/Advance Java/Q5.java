import java.sql.*;
public class Q5
{ 
  public static void main(String args[])
  {
  
    try
    {
	Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
	Connection con=DriverManager.getConnection("jdbc:odbc:abc");
	System.out.println("connection successfully");
	Statement st=con.createStatement();
	st.executeUpdate("create table employee(eno int,ename text(20),dept text(20),sal int)");
	System.out.println("table created");


	st.executeUpdate("insert into employee values(102,'abc','commerce',20000)");
	st.executeUpdate("insert into employee values(103,'xyz','computer science',50000)");
	st.executeUpdate("insert into employee values(104,'pqr','computer science',60000)");
	st.executeUpdate("insert into employee values(104,'pqr','arts',15000)");
	System.out.println("values inserted successfully");

	 ResultSet rs2=st.executeQuery("select * from employee");
         while(rs2.next())
         {
         System.out.println("eno:" +rs2.getInt(1)+"\t\t ename:"+rs2.getString(2)+"\tdept:"+rs2.getString(3)+"\tint:"+rs2.getInt(4));      
         }


	System.out.println();	
	ResultSet rs3=st.executeQuery("select * from employee where dept='computer science'");			
	while(rs3.next())
         {
         System.out.println("eno:" +rs3.getInt(1)+"\t\t ename:"+rs3.getString(2)+"\tdept:"+rs3.getString(3)+"\tint:"+rs3.getInt(4));      
         }

	st.executeUpdate("drop table employee");
	System.out.println("dropped table");
	
	con.close();
	st.close();
     }
	catch(Exception e)
	{}



 
   }
 }