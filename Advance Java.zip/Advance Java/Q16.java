import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
public class Q16 extends HttpServlet
{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws IOException,ServletException
	{
		response.setContentType("text/html");
		PrintWriter out = res.getWriter();
		String name = req.getParameter("name"),msg;
		String password = req.getParameter("password");
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		out.println("<HTML>");
		out.println("<BODY>");
		
		try
		{
			Class.forName("org.postgresql.Driver");
			
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			Connection cn = DriverManager.getConnection("jdbc:odbc:Q16");
			if(con==null)
				msg="Connection To Database Failed";
			else
			{
				st=con.createStatement();
				rs=st.executeQuery("select * from Login where name ='"+name+"' and password='"+password+"'");
				if(rs=null)
					
					out.println("NO SUCH USER!!!!");
					else
						out.println("Welcome :'"+name+"'");
			
			}
			
			catch(Exception e){}
			out.println("</BODY>");
			out.println("</HTML>");
			
		}
	}
	
}
	