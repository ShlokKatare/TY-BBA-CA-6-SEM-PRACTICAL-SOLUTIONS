import java.net.*;
import java.io.*;

class Q25_Server
{
	public static void main(String[] agrs) throws Exception
	{
		ServerSocket ss = new ServerSocket(1234);
		System.out.println("Waiting for client...");

		Socket s = ss.accept();
		InetAddress ia = s.getInetAddress();
		String addr = ia.getHostAddress();

		System.out.println("Connected to client: "+addr);

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		DataInputStream in  = new DataInputStream(s.getInputStream());
		DataOutputStream out  = new DataOutputStream(s.getOutputStream());

		while(true)
		{
			System.out.print("To Client: ");
			String cmsg = br.readLine();
			if(!cmsg.equals("exit"))
			{
				out.writeUTF(cmsg);
			}
			else
			{
				break;
			}
			System.out.println("From Client: "+in.readUTF());
		}

		in.close();
		out.close();
		ss.close();
		s.close();
	}
}