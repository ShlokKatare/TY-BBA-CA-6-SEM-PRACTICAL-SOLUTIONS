import java.sql.*;
class Q20
{
	public static void main(String args[])throws Exception
	{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		try
		{
			Connection cn=DriverManager.getConnection("jdbc:odbc:Percentage1");
			System.out.println("Connected Successfully");
			Statement st=cn.createStatement();
			st.executeUpdate("create table student(rno int,sname text(30),percentage int)");

			System.out.println("Table Created");
			st.executeUpdate("insert into student values(1,'Rahul',70)");
			st.executeUpdate("insert into student values(2,'Ram',90)");
		
			System.out.println("Value Added Successfully");
			
			ResultSet rs=st.executeQuery("select * from student");
			while(rs.next())	
		{
		System.out.println(rs.getInt(1)+"\t");
		System.out.println(rs.getString(2)+"\t");
		System.out.println(rs.getInt(3)+"\t");
		
		}

			st.close();
			
		
			
			Statement st1=cn.createStatement();
			
			st1.executeUpdate("alter table student drop percentage");
			System.out.println("Percentage Column Dropped Successfully");
		

			ResultSet rs1=st1.executeQuery("select * from student");
			while(rs1.next())
			{
				System.out.println(rs1.getInt(1)+"\t");
				System.out.println(rs1.getString(2)+"\t");
				
		
			}	


			st1.close();
			cn.close();
		}
		catch(SQLException e)
		{
		  System.out.println(e);
		}
	}
}
	