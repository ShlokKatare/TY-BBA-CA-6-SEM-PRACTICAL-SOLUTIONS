import java.sql.*;
class Q24
{
	public static void main(String args[])throws Exception
	{
	Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
	try 
	{
	Connection cn=DriverManager.getConnection("jdbc:odbc:abc");
	System.out.println("connected successfully");
	Statement st=cn.createStatement();
	st.executeUpdate("create table Mobile(ModelNo int,CompanyName text(20),Price int,Color text(10))");

	System.out.println("Table Created");

	st.executeUpdate("insert into Mobile values(4,'Nokia',10000,'Black')");
	st.executeUpdate("insert into Mobile values(2,'Samsung',9800,'Blue')");
	st.executeUpdate("insert into Mobile values(5,'RedMi',11000,'Red')");
	st.executeUpdate("insert into Mobile values(1,'Motorola',9000,'Voilet')");
	System.out.println("value added sucessfully");
	System.out.println();
	ResultSet rs=st.executeQuery("select * from Mobile");
	while(rs.next())	
		{
		System.out.println(rs.getInt(1)+"\t");
		System.out.println(rs.getString(2)+"\t");
		System.out.println(rs.getInt(3)+"\t");
		System.out.println(rs.getString(4)+"\t");
		}

	st.close();
	cn.close();
	}
	catch(SQLException e)
	{
		System.out.println(e);
	}
	}
}
