import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Q21 extends HttpServlet implements Servlet
	{
		public void doGet(HttpServletRequest request, HttpServletResponse response)throws IOException, ServletException
		{
			response.setContentType("text/html");
			PrintWriter pw=response.getWriter();
			HttpSession ses=request.getSession();

			pw.println("<html><body><b>Session Info</b><br><br>");
			pw.println("session timeout period :" + ses.getMaxInactiveInterval()+"seconds <br><br>");

			ses.setMaxInactiveInterval(40*60);
			pw.println("session time out period is now :" + ses.getMaxInactiveInterval()+" seconds ");
			pw.println("</body></html>");
		}

	}