import java.net.*;
import java.io.*;

class Q26_Client
{
	public static void main(String[] args) throws Exception
	{
		Socket s = new Socket("localhost",1234);
		System.out.println("Connected to: "+s.getRemoteSocketAddress());

		DataInputStream in = new DataInputStream(s.getInputStream());
		System.out.println("Date and Time: "+in.readUTF());

		s.close();
	}
}