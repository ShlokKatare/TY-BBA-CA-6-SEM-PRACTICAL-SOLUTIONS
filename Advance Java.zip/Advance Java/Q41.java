import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class Q41 extends HttpServlet
{
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws IOException,ServletException
	{
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			Connection con = DriverManager.getConnection("jdbc:odbc:Q23");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("Select * from Q41");
			out.print("<table border=1>");
			out.print("<tr><th>ProdCode</th><th>PName</th><th>Price</th></tr>");
			while(rs.next())
			{
				out.print("<tr><td>"+rs.getInt(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"</td></tr>");
			}
			out.print("</table>");
			
		}
		catch(SQLException e)
		{
			out.print(e);
		}
		catch(Exception e)
		{
			out.println(e);
		}
	}
}
	