import java.io.*;

class demo implements Runnable
{
	Thread t;
	demo(String s)
	{
		t=new Thread(this,s);
		System.out.println("new thread="+t);
		t.start();
	}
	public void run()
	{
		try
		{
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));					
			System.out.println("how many times u want to print:");
			int n=Integer.parseInt(br.readLine());
			for(int i=0;i<n;i++)
			{
				System.out.println("Thread Name:"+Thread.currentThread().getName());
				t.sleep(1000);
			}		
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}								
}
	public class Q7
	{
		public static void main(String args[])
 		{
			System.out.println("Thread Name:"+Thread.currentThread().getName());
	
			demo d1=new demo("HELLO JAVA");
		}
	}