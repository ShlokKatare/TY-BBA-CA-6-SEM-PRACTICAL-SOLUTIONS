import java.sql.*;
public class q18
{
  public static void main(String args[])
  {
     try
     {
	Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
	Connection con=DriverManager.getConnection("jdbc:odbc:abcDsn");
	System.out.println("connected successfully");

	Statement st=con.createStatement();
	st.executeUpdate("create table emp(eid int,ename text(10),eaddr text(20))");
	System.out.println("table created successfully");
	
	st.executeUpdate("insert into emp values(101,'abc','pune')");
	st.executeUpdate("insert into emp values(102,'xyz','mumbai')");
	st.executeUpdate("insert into emp values(103,'pqr','pune')");
	st.executeUpdate("insert into emp values(103,'pqr','pune')");
	System.out.println("values inserted successfully");
	System.out.println();	
	ResultSet rs3=st.executeQuery("select * from emp");			
	int cnt=0;
	while(rs3.next())
         {
         System.out.println("eno:" +rs3.getInt(1)+"\t\t ename:"+rs3.getString(2)+"\t  eaddr:"+rs3.getString(3));      
	cnt++;
	
         }
	System.out.println("total no. of record" + cnt);
	



	
	con.close();
	st.close();
     }
	catch(Exception e)
	{}



 
   }
 }
