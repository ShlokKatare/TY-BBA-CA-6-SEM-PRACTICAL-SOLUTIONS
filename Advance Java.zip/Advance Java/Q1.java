import java.net.*;

class Q1
{
	public static void main(String[] args) throws Exception
	{
		System.out.println("IP Address: "+InetAddress.getLocalHost());
	}
}