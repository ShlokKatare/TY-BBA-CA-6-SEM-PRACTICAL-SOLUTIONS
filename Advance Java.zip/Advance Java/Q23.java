import java.io.*;
import java.sql.*;

public class slip23
{
 public static void main(String args[])throws Exception
 {
   Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");

   
   try
    {
	  BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

                 Connection con=DriverManager.getConnection("jdbc:odbc:Q23");

                  System.out.println("Connection done");
  
                 Statement stmt = con.createStatement();
                 stmt.executeUpdate("Create table acc(Account_No int,Type text(20),Balance int)");
                 System.out.println("Connection done");
               }
                 catch(Exception e)
            {
               System.out.println(e);
   }
 }
 }
	  