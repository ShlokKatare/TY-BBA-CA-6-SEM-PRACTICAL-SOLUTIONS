public class Slip4 implements Runnable{
   
    int i,no;
   
    Slip4(int n)
    {
        no = n;
    }
    public void run()
    {
        for(i = 1; i<=no; i++)
        {
            System.out.println("\nHello Java");
           
            try
            {
                Thread.sleep(50);
            }
            catch(Exception e)
            {
                System.out.println(e);
            }
        }
    }
   
    public static void main(String args[])
    {
        try
        {
        int n;
       
        System.out.println("\nEnter Number : ");
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String s = br.readLine();
        n = Integer.parseInt(s);
        Thread t = new Thread(new Slip4(n));
        t.start();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}