import java.sql.*;
public class q28
{
  public static void main(String args[])
  {
     try
     {
	Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
	Connection con=DriverManager.getConnection("jdbc:odbc:Java");
	System.out.println("connected successfully");

	Statement st=con.createStatement();
	st.executeUpdate("create table customer(cid int,cname text(10),caddr text(20))");
	System.out.println("table created successfully");
	
	st.executeUpdate("insert into customer values(101,'abc','pune')");
	st.executeUpdate("insert into customer values(102,'xyz','pune')");
	st.executeUpdate("insert into customer values(103,'pqr','pune')");
	System.out.println("values inserted successfully");
	System.out.println();	
	ResultSet rs3=st.executeQuery("select * from customer");			
	while(rs3.next())
         {
         System.out.println("cno:" +rs3.getInt(1)+"\t\t cname:"+rs3.getString(2)+"\t  caddr:"+rs3.getString(3));      
         }

	System.out.println();	
		System.out.println("Updated Address whose Customer Id is 102");
	st.executeUpdate("update customer set caddr ='mumbai' where cid=102");	
	rs3=st.executeQuery("select * from customer");		
	while(rs3.next())
         {
        System.out.println("cno:" +rs3.getInt(1)+"\t\t cname:"+rs3.getString(2)+"\t  caddr:"+rs3.getString(3));      
         }



	
	con.close();
	st.close();
     }
	catch(Exception e)
	{}



 
   }
 }
