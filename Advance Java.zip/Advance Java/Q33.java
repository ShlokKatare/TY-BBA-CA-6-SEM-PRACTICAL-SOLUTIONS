class Q33 extends Thread
{
	Q33(String str)
	{
		super(str);
		start();
	}
	public void run()
	{
		display(Thread.currentThread().getName());
	}
	public synchronized void display(String str)
	{
		System.out.println("Hello");
		System.out.println("There");
	}

public static void main(String args[])
		{
			Q33 t1 = new Q33("Thread 1");
			Q33 t2 = new Q33("Thread 2");
		}	
}		