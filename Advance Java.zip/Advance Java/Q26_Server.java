import java.net.*;
import java.io.*;

class Q26_Server
{
	public static void main(String[] agrs) throws Exception
	{
		ServerSocket ss = new ServerSocket(1234);
		System.out.println("Waiting for client...");

		Socket s = ss.accept();
		InetAddress ia = s.getInetAddress();
		String addr = ia.getHostAddress();

		System.out.println("Connected to client: "+addr);

		DataOutputStream out  = new DataOutputStream(s.getOutputStream());

		out.writeUTF(new java.util.Date().toString());

		out.close();
		ss.close();
		s.close();
	}
}