import java.sql.*;
public class q17
{
    public static void main(String args[])
    {
        try
        {
	Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
	Connection con=DriverManager.getConnection("jdbc:odbc:Java");
	System.out.println("connected successfully");
	
	Statement st=con.createStatement();
	st.executeUpdate("create table employees(eno int,ename text(10),eaddr text(20))");
	System.out.println("table created");

	st.executeUpdate("insert into employees values(10,'Abc','pune')");
	st.executeUpdate("insert into employees values(11,'Xyz','mumbai')");
	st.executeUpdate("insert into employees values(12,'Aryan','nashik')");
	System.out.println("values inserted successfully");

	System.out.println();	
	ResultSet rs3=st.executeQuery("select * from employees");			
	while(rs3.next())
         {
	System.out.println("Deleted Records Whose Name Started With 'A'");
         System.out.println("eno:" +rs3.getInt(1)+"\t\t ename:"+rs3.getString(2)+"\t  eaddr:"+rs3.getString(3));      
         }

	System.out.println();	
	st.executeUpdate("delete from employees where ename like 'A%'");	
	rs3=st.executeQuery("select * from employees");		
	while(rs3.next())
         {
         System.out.println("eno:" +rs3.getInt(1)+"\t\t ename:"+rs3.getString(2)+"\t  eaddr:"+rs3.getString(3));      
         }



	
	con.close();
	st.close();
     }
	catch(Exception e)
	{}



 
   }
 }