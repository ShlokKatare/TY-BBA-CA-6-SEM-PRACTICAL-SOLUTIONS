import java.io.*;
import java.lang.*;
import java.util.*;
class Vowels extends Thread
{
	String s;
	char ch;
	boolean flag=false;
	Vowels(String str)
	{
		s=str;
		start();
	}
	public void run()
	

	{
		for(int i=0;i<s.length();i++)

		{
			ch=s.charAt(i);
			if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u'||ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U')
			{
			
			System.out.print(" "+ch);
			flag=true;
			}
		}
			if(flag==false)
				{
					System.out.println("No Vowels Found!!!!!!"); 
				}
						
	}
	
}

public class Q3
{

	public static void main(String args[]) throws IOException
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter A String:");
		String vw = br.readLine();
		Vowels v = new Vowels(vw);
	}


}

