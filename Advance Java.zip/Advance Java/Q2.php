<?php
session_start();
session_register("chance");
if($_SERVER['REQUEST_METHOD']=='GET')
{
 ?>
<form method=post action="<?php echo $_SERVER['PHP_SELF']?>">
<P>Name : <input type=text name=uname value="<?php if(isset($_POST['uname'])) echo $_POST['uname'];?>"></p>
<P>Passoword : <input type=text name=pass value="<?php if(isset($_POST['pass'])) echo $_POST['pass'];?>"></p>
<input type=submit name=submit value=submit>
</form>
<?php
}
else if($_SERVER['REQUEST_METHOD']=='POST')
{
$name=$_POST['uname'];
$pass=$_POST['pass'];
if(($name=="ABC") && ($pass=="abc"))
echo"Hello <a href='next.php'>next form</a>";
else
echo"wrong username password ".session_register("chance")."!!!";
$chance++;
if($chance==3)
echo"sorry!!! your chance are finished!!!!!";
}
else
{
 die("not able to process script");
}
?>