import java.sql.*;
public class q38
{
  public static void main(String args[])
  {

    try
    {
	Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
	Connection con=DriverManager.getConnection("jdbc:odbc:Java");
	System.out.println("connected successfully");
	
	Statement st=con.createStatement();
	st.executeUpdate("create table employeees(eno int,ename text(20),eaddr text(20))");
	System.out.println("employees table created...");
	
	st.executeUpdate("insert into employeees values(120,'Dhoni','pune')");
	st.executeUpdate("insert into employeees values(122,'Virat','mumbai')");
	st.executeUpdate("insert into employeees values(124,'sram','pune')");
	System.out.println("values added successfully");

	System.out.println();	
	ResultSet rs3=st.executeQuery("select * from employeees");			
	while(rs3.next())
         {
         System.out.println("eno:" +rs3.getInt(1)+"\t\t ename:"+rs3.getString(2)+"\t  eaddr:"+rs3.getString(3));      
         }

	System.out.println();	
		
	rs3=st.executeQuery("select * from employeees where ename like 'S%'");			
	while(rs3.next())

         {
	System.out.println("Names Of Employee Starting With 'S' Character");
         System.out.println("eno:" +rs3.getInt(1)+"\t\t ename:"+rs3.getString(2)+"\t  eaddr:"+rs3.getString(3));      
         }



	
	con.close();
	st.close();
     }
	catch(Exception e)
	{}



 
   }
 }