<?php
$rem=simplexml_load_file("Q14.xml");

var_dump($rem);
?>
