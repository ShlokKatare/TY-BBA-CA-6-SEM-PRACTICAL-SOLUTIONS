<html>
	<head>
		<script type="text/javascript">
			function val_user(str)
			{
				var ob=false;
				ob=new XMLHttpRequest();

				if(str=="")	document.getElementById("a").innerHTML="Enter username";
				else if(str.length < 3)				document.getElementById('a').innerHTML="Username too short";
				else document.getElementById('a').innerHTML="Valid username";
}
		</script>
	</head>
	<body>
		<form>
		Enter Username:<input type=text name=u_name id=u_name><br>
		<input type=button value=submit onclick="val_user(form.u_name.value)"><br>
		<span id=a></span>
		</form>
	</body>
</html>
