<?php
echo "<table border=1>";
foreach($_SERVER as $K=>$v)
{
	echo "<tr><td>".$K."</td><td>".$v."</td></tr>";
	
}
echo "</table>";
?>
	