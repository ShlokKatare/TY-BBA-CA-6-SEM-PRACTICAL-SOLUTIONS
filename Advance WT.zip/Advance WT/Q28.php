<?php
$gm = $_GET['game'];
$a = array("Hockey","Football","Tennis","Chess","Cricket");
echo "List Of Games:<br>";
for($i=0;$i<count($a);$i++)
{
	echo $a[$i]."<br>";
}	