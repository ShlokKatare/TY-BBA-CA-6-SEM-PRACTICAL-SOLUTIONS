<html>
<head>
<title>Q4</title>
</head>
<body>
<form method="POST" action="<?php echo $_SERVER['PHP_SELF']?>">
<h3>Student Registration Form!!!!</h3>
Student Name : <input type="text" name="sname" value="<?php if(isset ($_POST['sname'])) echo $_POST['sname'];?>" ></br>

Student Mobile No : <input type="text" name="mob" value="<?php if(isset ($_POST['mob'])) echo $_POST['mob'];?>" ></br>

Student E-mail : <input type="text" name="semail" value="<?php if(isset($_POST['semail']))echo $_POST['semail'];?>" ></br>

Student Class : <input type="text" name="sclass" value="<?php if(isset($_POST['sclass'])) echo $_POST['sclass'];?>" ></br>

<input type="submit" value="SUBMIT" name="submit">

<?php
if(isset($_POST['submit']))
{
$name = $_POST['sname'];
$no = $_POST['mob'];
$email = $_POST['semail'];
$class = $_POST['sclass'];
}
if((!empty($name))  && (!empty($no)) && (!empty($email)) && (!empty($class)))
{
  setcookie('sname',$name);
  setcookie('mob',$no);
  setcookie('semail',$email);
  setcookie('sclass',$class);
  

header("location:Q4next.php");
}
?>

