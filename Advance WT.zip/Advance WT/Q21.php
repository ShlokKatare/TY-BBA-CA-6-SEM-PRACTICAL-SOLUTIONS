<?php
$n=$_POST["name"];
$conn=Mysql_connect("localhost","root","admin");
if($conn)
{
	 echo " connection successful"."</br>";
}
Mysql_select_db("Q21",$conn);

$resultset=mysql_query("select doc_name,address,city,area,time from doctor,hospital,dh where doctor.doc_no=dh.doc_no and hospital.hosp_no=dh.hosp_no 
and hosp_name='$n'",$conn);


echo "<table border=1>";
//echo "<tr><th>Doctor No</th></tr>";
echo "<tr><th>Doctor Name</th>";
echo "<th>Doctor Address</th>";
echo "<th>Doctor City</th>";
echo "<th>Doctor Area</th>";
echo "<th>Doctor Visiting Time</th></tr>";
while($r=Mysql_fetch_array($resultset))
{
	//echo"<tr><td>.$r[doc_no];</td></tr>";
	echo"<tr><td>.$r[doc_name];</td>";
	echo"<td>.$r[address];</td>";
	echo"<td>.$r[city];</td>";
	echo"<td>.$r[area];</td>";
	echo"<td>.$r[time];</td></tr>";
	
}
echo "</table>";

Mysql_close($conn);
?>
