<?php
session_start();
if(isset($_SESSION["count"]))
{
	$accesses=$_SESSION["count"]+1;
	
}
else
{
		$accesses=1;
		
}

$_SESSION["count"]=$accesses;

echo"You Have Accessed This Page $accesses Times";
?>
		