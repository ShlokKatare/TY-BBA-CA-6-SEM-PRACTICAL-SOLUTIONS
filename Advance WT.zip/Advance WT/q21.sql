-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 04, 2020 at 10:03 AM
-- Server version: 5.5.24
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `q21`
--

-- --------------------------------------------------------

--
-- Table structure for table `dh`
--

CREATE TABLE IF NOT EXISTS `dh` (
  `doc_no` int(10) NOT NULL,
  `hosp_no` int(10) NOT NULL,
  `time` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dh`
--

INSERT INTO `dh` (`doc_no`, `hosp_no`, `time`) VALUES
(1, 11, 10),
(2, 12, 6);

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE IF NOT EXISTS `doctor` (
  `doc_no` int(10) NOT NULL AUTO_INCREMENT,
  `doc_name` varchar(30) NOT NULL,
  `address` varchar(50) NOT NULL,
  `city` varchar(10) NOT NULL,
  `area` varchar(10) NOT NULL,
  PRIMARY KEY (`doc_no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`doc_no`, `doc_name`, `address`, `city`, `area`) VALUES
(1, 'Saurabh', 'sangvi', 'Pune', 'Sai Chowk'),
(2, 'Narhari', 'Sangvi', 'Pune', 'Sai Chowk');

-- --------------------------------------------------------

--
-- Table structure for table `hospital`
--

CREATE TABLE IF NOT EXISTS `hospital` (
  `hosp_no` int(10) NOT NULL AUTO_INCREMENT,
  `hosp_name` varchar(30) NOT NULL,
  `hosp_city` varchar(10) NOT NULL,
  PRIMARY KEY (`hosp_no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `hospital`
--

INSERT INTO `hospital` (`hosp_no`, `hosp_name`, `hosp_city`) VALUES
(11, 'Sangvi Hospital', 'Pune'),
(12, 'Sangvi Hospital', 'Pune');
