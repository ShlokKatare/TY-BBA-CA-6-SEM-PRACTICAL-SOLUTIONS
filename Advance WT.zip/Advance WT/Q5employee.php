<?php
$name=$_POST["ename"];
$addr=$_POST["addr"];
$mob_no=$_POST["mbno"];

setcookie("ename",$name);

setcookie("addr",$addr);

setcookie("mbno",$mob_no);
?>
