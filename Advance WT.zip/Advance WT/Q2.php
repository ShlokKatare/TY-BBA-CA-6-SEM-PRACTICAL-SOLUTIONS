<?php
class Person
{
	var $name,$age;
	function First()
	{
		echo "Method 1st"."<br>";
	}
}
class Student extends Person
{
		var $rno,$b_date;
		function Second()
		{
			echo "Method 2nd"."<br>";
		}
}

$t=new Person();
$t1=new Student();

$classes=get_declared_classes();
foreach($classes as $c)
{
		echo "$c"."<br>";
}
$m=get_class_methods($c);
echo "$m"."<br>";

$p=get_class_vars($c);

foreach($p as $v)
{
echo "$v"."<br>";
}
?>
	
