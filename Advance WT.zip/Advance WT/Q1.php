<html>
<body>
<form method="POST" action="<?php echo$_SERVER['PHP_SELF'] ?>" >
Enter First Number: <input type="number" name="n1"> <br>

Enter Second Number: <input type="number" name="n2"> <br>
<select name="cal">
  <option value="1"> Addition </option>
  <option value="2"> Subtraction </option>
  <option value="3"> Multiplication </option>
  <option value="4"> Division </option>
</select> <br>

<input type="Submit" name="Submit" value="OK">
</form>

<?php
if(isset($_POST['Submit']))
{
  $n1=$_POST['n1'];
  $n2=$_POST['n2'];
  $cal=$_POST['cal'];
  if((!empty($n1)) && (!empty($n2)))
  {
    switch($cal)
	{
	 case 1:$add=$n1+$n2;
	        echo "Addtion is $add"; break;
	 case 2:$sub=$n1-$n2;
	        echo "Subtraction is $sub"; break;
	 case 3:$multi=$n1*$n2;
	        echo "Multiplication is $multi"; break;
	 case 4:$divi=$n1/$n2;
	        echo "Division is $divi"; break;
	}
  }
   else
   {
     echo "Please enter 2 nos";
   }
}
   else
   {
     die("Not Access");
   }
   ?>
   </body>
   </html>