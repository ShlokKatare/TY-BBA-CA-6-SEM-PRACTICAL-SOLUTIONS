<?php
if(isset($_COOKIE['cnt']))
{
  $x=$_COOKIE['cnt'];
  $x=$x+1;
  setcookie('cnt',$x);
}
else
{
setcookie('cnt',$x);
echo "you accessed this page 1st  time";
}
echo “You accessed this page  $_COOKIE[cnt]  times”;

?>