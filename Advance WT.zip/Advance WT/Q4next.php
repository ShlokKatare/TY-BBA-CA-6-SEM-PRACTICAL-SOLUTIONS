<?php
echo "Student Name Is : $_COOKIE[sname]</br>";
echo "Student Mobile No :$_COOKIE[mob]</br>";
echo "Student E-mail Id Is :$_COOKIE[semail]</br>";
echo "Student Class Is : $_COOKIE[sclass]</br>";

?>