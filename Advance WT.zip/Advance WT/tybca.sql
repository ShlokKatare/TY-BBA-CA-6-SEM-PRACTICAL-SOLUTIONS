-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 04, 2020 at 10:04 AM
-- Server version: 5.5.24
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tybca`
--

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE IF NOT EXISTS `project` (
  `P_Group_No` int(10) NOT NULL AUTO_INCREMENT,
  `Project_Title` varchar(30) NOT NULL,
  PRIMARY KEY (`P_Group_No`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`P_Group_No`, `Project_Title`) VALUES
(1, 'MAC'),
(2, 'fhdjgh'),
(11, 'MAC'),
(22, 'fhdjgh');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `Seatno` int(10) NOT NULL AUTO_INCREMENT,
  `Name` varchar(30) NOT NULL,
  `Class` varchar(30) NOT NULL,
  `P_Group_No` int(10) NOT NULL,
  PRIMARY KEY (`Seatno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`Seatno`, `Name`, `Class`, `P_Group_No`) VALUES
(1, 'abc', 'tybca', 11),
(2, 'xyz', 'sybca', 22),
(11, 'safdf', 'fdgg', 11);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`Seatno`) REFERENCES `project` (`P_Group_No`);
