<?php

define("pi","3.14");
    $r=$_POST["r"];
	$h=$_POST["h"];
interface shape
{
	
	public function area();
	public function volume();
}
class Cylinder implements shape
{
	
    
	
	function cylinder($r,$h)
	{
		
		$this->r=$r;
		$this->h=$h;
	}
    function area()
	{
		$a=pi*$this->r*$this->r*$this->h;
		echo"Area of Cylinder=$a<br><br>";
		
		
	}
	function volume()
	{
		$a=2*(pi*$this->r*$this->h);
		echo"Volume of Cylinder=$a";
		
	}	
	
}	
    $r=$_POST["r"];
	$h=$_POST["h"];
    $c=new Cylinder($r,$h);

	$c->area();
	$c->volume();







?>