<?php
session_start();
if(time()-$_SESSION['time']>10)
{
	echo "Session Expired";
	session_destroy();
	
}
else
{
		echo "Student Name:".$_POST['name']."<br>";
		echo "City:".$_POST['city']."<br>";
		echo "Phno:".$_POST['phno']."<br>";
		
}
?>
		