<html>
<body>
<?php
session_start();
session_register("chance");
if($SERVER['REQUEST_METHOD']=="GET")
{
?>
<form method="post" action="<?php echo $_SERVER['PHP_SELF'] ?>">
Name:
<input type="text" name="uname" value="<?php if(isset($_POST['uname']))
echo $_POST['uname'];?>">
Password:
<input type="text" name="pass" value="<?php if(isset($_POST['pass']))
echo $_POST['pass'];?>">
<input type="submit" value="submit">
</form>
<?php
}
else if($_SERVER['REQUEST_METHOD']=='POST')
{
$name = $_POST['uname'];
$pass = $_POST['pass'];
if(($name=="ABC") && ($pass=="abc"))
echo "Valid";
else
echo "Invalid" session_register("chance")."!";
$chance++;
if($chance==3)
echo "Sorry";
else
die("not process");
?>