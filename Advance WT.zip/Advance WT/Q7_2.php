<?php
echo "<h3>Marksheet</h3> ";

echo "Name : ".$_COOKIE['stud1']."<br>";
echo "Address : ".$_COOKIE['stud2']."\n";
echo "Class : ".$_COOKIE['stud3']."\n";

echo "Java : ".$_POST['m1']."\n";
echo "PHP : ".$_POST['m2']."\n";
echo "ST : ".$_POST['m3']."\n";
echo "IT : ".$_POST['m3']."\n";
echo "Practical : ".$_POST['m3']."\n";
echo "Project : ".$_POST['m3']."\n";

?>