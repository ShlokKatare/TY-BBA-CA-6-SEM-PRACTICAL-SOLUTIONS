<?php
$pno=$_POST["pno"];
$pname=$_POST["pname"];
$pre=$_POST["pre"];

echo "Employee Details"."<br>";

echo "Employee Name:".$_COOKIE['ename']."<br>";

echo "Address:".$_COOKIE['addr']."<br>";

echo "Mobile No:".$_COOKIE['mbno']."<br>";

echo "Emp Policy No Is $pno <br> Policy Name Is $pname <br> Premium No Is $pre<br>";

?>
