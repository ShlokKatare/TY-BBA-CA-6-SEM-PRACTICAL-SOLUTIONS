<?php
$n=$_POST["title"];
$conn=Mysql_connect("localhost","root","admin");
if($conn)
{
	 echo " connection successful"."</br>";
}
Mysql_select_db("tybca",$conn);

$resultset=mysql_query("select Name from student,project where project.P_Group_No=student.P_Group_No and Project_Title='$n'",$conn);
echo "<table border=1>";
echo "<tr><th>name</th></tr>";
while($r=Mysql_fetch_array($resultset))
{
	echo"<tr><td>.$r[Name];</td></tr>";
}
echo "</table>";

Mysql_close($conn);
?>
