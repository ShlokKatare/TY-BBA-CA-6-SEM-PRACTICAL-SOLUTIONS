<?php
$ele = $_POST["title"];
$attr = $_POST["pub"];

$xmltags = "<?xml version=\"1.0\" ?>";
$xmltags = $xmltags."<BookStore>";
	$xmltags = $xmltags."<Books>";
	$xmltags = $xmltags."<PHP>";
	$xmltags = $xmltags."<title>";
	$xmltags = $xmltags."Programming PHP";
	$xmltags = $xmltags."</title>";
	$xmltags = $xmltags."<publication>";
	$xmltags = $xmltags."O'RELLY";
	$xmltags = $xmltags."</publication>";
	$xmltags = $xmltags."</PHP>";
	$xmltags = $xmltags."<PHP>";
	$xmltags = $xmltags."<title>";
	$xmltags = $xmltags."Begining PHP";
	$xmltags = $xmltags."</title>";
	$xmltags = $xmltags."<publication>";
	$xmltags = $xmltags."WROX";
	$xmltags = $xmltags."</publication>";
	$xmltags = $xmltags."</PHP>";
	$xmltags = $xmltags."</Books>";
	$xmltags = $xmltags."</BookStore>";

$fp = fopen("bookstore.xml","w");
fwrite($fp,$xmltags);
fclose($fp);	

?>