<?php
echo "Filename:".$_FILES['file']['name']."</br>";
$f=$_FILES['file']['size'];
echo "size:".$f."</br>";
echo "File name on server:".$_FILES['file']['tmp_name']."<br>";


echo "File error:".$_FILES['file']['error']."<br>";
print_r($_FILES);
?>
 