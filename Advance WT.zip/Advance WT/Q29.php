<?php
$q=$_GET["q"];
$dom=new DOMDocument();
$dom->("Q29.xml");
$x=$dom->getElementsByTagName("BUSNAME");
for($i=0; $i<=$x->length-1;$i++)
{
if($x->item($i)->nodeType==1)
{
if($x->item($i)->childNodes->item(0)->nodeValue==$q)
{
$y=($x->item($i)->parentNode);
}
}
}
$lang=($y->childNodes);
for($i=0;$i<$lang->length;$i++)
{
if($lang->item($i)->nodeType==1)
{
echo("".$lang->item($i)->nodeName."");
echo($lang->item($i)->childNodes->item(0)->nodeValue);
echo("
");
}
}
?>

