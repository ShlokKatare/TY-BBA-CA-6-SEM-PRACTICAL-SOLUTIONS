<html>
<head>
<title>Q3</title>
</head>
<body>
<form action="<?php echo $_SERVER['PHP_SELF']?>" method=post>
UserName:
<input type=text name=uname value="<?php if(isset($_POST['uname']))echo $_POST['uname'];?>" ></br>
Password:
<input type=text name=upass value="<?php if(isset($_POST['upass']))echo $_POST['upass'];?>" ></br>
<input type=submit value="Login" name=submit>

<?php
if(isset($_POST['submit']))
$nm=$_POST["uname"];
$ps=$_POST["upass"];
$con=Mysql_connect("localhost","root","admin");
Mysql_select_db("Q3",$con);

$result=mysql_query("select * from login where uname='$nm' and upass='$ps'");
$flag=0;
while($row=mysql_fetch_array($result))
{
  $flag++;
}
if($flag==1)
  echo "Login validated";
else
  echo "username or password invalid";
mysql_close($con);
?>
</body>
</html>