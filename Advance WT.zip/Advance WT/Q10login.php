<?php
$uname=$_POST["uname"];
$pwd=$_POST["pwd"];

if(($uname=="TYBBACA")&&($pwd=="TYBBACA"))
{
	session_start();
	$_SESSION['time']=time();
	
	echo"<form method='POST' action='Q10disp.php'>";
	echo "Student Name: <input type='text' name='name'> <br>";
	echo "City: <input type='text' name='city'> <br>";
	echo "Phno: <input type='number' name='phno'> <br>";
	
	echo "<input type='submit' value='OK'>";
	echo"</form>";
	
}
else
{
		echo "Wrong Info <ahref='info.html'>Go Back</a>";
		
}
?>
		